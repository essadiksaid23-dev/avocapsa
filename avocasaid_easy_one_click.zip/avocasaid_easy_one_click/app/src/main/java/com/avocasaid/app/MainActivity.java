package com.avocasaid.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;

public class MainActivity extends Activity {
    int navy = Color.rgb(37, 23, 80);
    int gold = Color.rgb(246, 196, 83);
    LinearLayout list;
    String[][] cases = {
            {"2026/118", "ملف شغلي", "سعيد أ.", "المحكمة الابتدائية", "غداً 09:30", "جلسة قريبة"},
            {"2026/044", "نزاع تجاري", "شركة النور", "المحكمة التجارية", "03 يونيو", "إعداد مذكرة"},
            {"2025/390", "قسمة عقار", "فاطمة ب.", "المحافظة العقارية", "10 يونيو", "تتبع"}
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(navy);
        ScrollView rootScroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(22));
        root.setBackgroundColor(Color.rgb(248,250,252));
        rootScroll.addView(root);

        LinearLayout header = row(); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(0,0,0,dp(20));
        TextView logo = tv("⚖", 30, Color.WHITE, true); logo.setGravity(Gravity.CENTER); logo.setBackground(round(navy, dp(22)));
        header.addView(logo, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout titleBox = col(); titleBox.setPadding(dp(12),0,0,0);
        titleBox.addView(tv("مرحبا بك في", 12, Color.GRAY, false));
        titleBox.addView(tv("avocasaid", 28, navy, true));
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        TextView bell = tv("🔔", 24, navy, false); bell.setGravity(Gravity.CENTER); bell.setBackground(round(Color.WHITE, dp(18)));
        header.addView(bell, new LinearLayout.LayoutParams(dp(48), dp(48)));
        root.addView(header);

        LinearLayout hero = col(); hero.setPadding(dp(18), dp(18), dp(18), dp(18)); hero.setBackground(round(Color.WHITE, dp(26)));
        hero.addView(tv("لوحة مكتب المحامي", 14, Color.GRAY, false));
        hero.addView(tv("تدبير الملفات، الجلسات والوثائق", 22, Color.rgb(20,20,30), true));
        Button add = new Button(this); add.setText("+ ملف جديد"); add.setTextColor(Color.WHITE); add.setTextSize(16); add.setBackground(round(navy, dp(18))); hero.addView(add, new LinearLayout.LayoutParams(-1, dp(56)));
        root.addView(hero);

        LinearLayout stats = row(); stats.setPadding(0, dp(14),0,dp(14));
        stats.addView(stat("24", "ملفات نشطة"), new LinearLayout.LayoutParams(0, dp(86), 1));
        stats.addView(stat("07", "جلسات"), new LinearLayout.LayoutParams(0, dp(86), 1));
        stats.addView(stat("38", "موكلين"), new LinearLayout.LayoutParams(0, dp(86), 1));
        root.addView(stats);

        EditText search = new EditText(this); search.setHint("بحث في الملفات أو الموكلين..."); search.setSingleLine(true); search.setTextDirection(View.TEXT_DIRECTION_RTL); search.setPadding(dp(15),0,dp(15),0); search.setBackground(round(Color.WHITE, dp(20))); root.addView(search, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView section = tv("الملفات المهمة", 20, Color.rgb(20,20,30), true); section.setPadding(0, dp(20),0,dp(8)); root.addView(section);
        list = col(); root.addView(list); renderCases("");
        search.addTextChangedListener(new android.text.TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){ renderCases(s.toString()); } public void afterTextChanged(android.text.Editable e){} });

        LinearLayout assistant = col(); assistant.setPadding(dp(18), dp(18), dp(18), dp(18)); assistant.setBackground(round(navy, dp(26)));
        assistant.addView(tv("المساعد الذكي", 14, Color.LTGRAY, false)); assistant.addView(tv("صياغة مذكرات وتتبع الآجال", 19, Color.WHITE, true));
        assistant.addView(task("إعداد مذكرة تعقيبية قبل 18:00")); assistant.addView(task("رفع نسخة الحكم في ملف 2026/118")); assistant.addView(task("الاتصال بالموكل لتأكيد الوثائق"));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2); ap.setMargins(0, dp(18),0,0); root.addView(assistant, ap);
        setContentView(rootScroll);
    }

    void renderCases(String q){ list.removeAllViews(); for(String[] c: cases){ String all=TextUtils.join(" ", c); if(q.length()==0 || all.contains(q)) list.addView(card(c)); } }
    TextView task(String s){ TextView v=tv("📄  "+s, 14, Color.WHITE, false); v.setPadding(dp(12),dp(10),dp(12),dp(10)); v.setBackground(round(Color.argb(35,255,255,255), dp(16))); return v; }
    View stat(String n,String l){ LinearLayout s=col(); s.setGravity(Gravity.CENTER); s.setBackground(round(Color.WHITE, dp(20))); s.addView(tv(n,24,navy,true)); s.addView(tv(l,12,Color.GRAY,false)); return s; }
    View card(String[] c){ LinearLayout box=col(); box.setPadding(dp(16),dp(14),dp(16),dp(14)); box.setBackground(round(Color.WHITE, dp(22))); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2); bp.setMargins(0,0,0,dp(10)); box.setLayoutParams(bp); box.addView(tv("#"+c[0]+"   "+c[1],17,Color.rgb(20,20,30),true)); box.addView(tv(c[2]+" • "+c[3],14,Color.GRAY,false)); TextView d=tv("🕒 "+c[4]+"        "+c[5],13,navy,true); d.setPadding(0,dp(8),0,0); box.addView(d); return box; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    TextView tv(String t,int sp,int color,boolean bold){ TextView v=new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); v.setTextDirection(View.TEXT_DIRECTION_RTL); if(bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return v; }
    GradientDrawable round(int color,int r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(r); return g; }
    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density+.5f); }
}
