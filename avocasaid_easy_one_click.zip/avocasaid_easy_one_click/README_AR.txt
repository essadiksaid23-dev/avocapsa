ملف avocasaid جاهز للبناء بدون Android Studio.

أسهل طريقة من الهاتف فقط:
1) افتح github.com وسجل الدخول.
2) أنشئ Repository جديد باسم avocasaid.
3) ارفع كل ملفات هذا المجلد إلى Repository.
4) افتح تبويب Actions.
5) اختر Build avocasaid APK ثم Run workflow.
6) بعد نهاية البناء، افتح Artifacts وحمل avocasaid-apk.
7) داخل الملف ستجد app-debug.apk، ثبته في هاتفك.

ملاحظة مهمة:
هذا APK سيكون Debug، لذلك عند التثبيت قد يطلب الهاتف السماح بالتثبيت من مصادر غير معروفة.
